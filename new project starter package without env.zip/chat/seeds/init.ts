import { logger } from "../src/logger";

export async function seed(): Promise<void> {
  logger.info("Starting seeder");

  logger.info("Seeder run Complete");
}
