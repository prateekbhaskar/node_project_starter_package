import { Request, Response, NextFunction } from "express";
import { CustomError, safeStringify } from "../utilities/common.utility";
import { createFailureResponse } from "../utilities/response";
import { GeneralApiResponseCode } from "../utilities/api-response";
import httpStatusCode from "http-status-codes";
import { logger } from "../logger";
import ApiResponse from "../utilities/api-response";

/**
 * Express middleware for handling errors in the application.
 * Logs the error if it is not an instance of CustomError and sends a standardized error response.
 *
 * @param {any} err - The error object, which may
 * include custom properties like `apiMessage`, `responseCode`, and `httpCode`.
 * @param {Request} _req - The Express request object (unused in this middleware).
 * @param {Response} res - The Express response object used to send the error response.
 * @param {NextFunction} _next - The next middleware function (unused in this middleware).
 * @returns {void} Sends a JSON response with the error details.
 */
export function ErrorHandlerMiddleware(
  err: any,
  _req: Request,
  res: Response,
  _next: NextFunction
) {
  let message: string = "Something went wrong";
  if (!(err instanceof CustomError)) {
    logger.error(safeStringify(err));
    message = err.message;
  }

  return ApiResponse.controllerResponse(
    res,
    createFailureResponse(
      err.apiMessage || message,
      err.apiData || {},
      err.responseCode || GeneralApiResponseCode.PROCESSING_FAILED,
      err.httpCode || httpStatusCode.INTERNAL_SERVER_ERROR
    )
  );
}
