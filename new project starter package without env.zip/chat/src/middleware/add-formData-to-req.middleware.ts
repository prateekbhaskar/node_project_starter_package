import busboy from "busboy";
import { VALID_UPLOAD_EXTENSIONS } from "../constants/constants";
import { NextFunction, Request, Response } from "express";
import { CustomError } from "../utilities/common.utility";
import httpStatusCodes from "http-status-codes";
import { GeneralApiResponseCode } from "../utilities/api-response";
import path from "path";

export default function addFormDataToBody(
  options: {
    fileLimit: number;
    allowedExtensions?: string[];
  } = {
    fileLimit: 1,
    allowedExtensions: VALID_UPLOAD_EXTENSIONS,
  }
) {
  return (req: Request, res: Response, next: NextFunction) => {
    const errorName = "FormDataToBodyMiddleware";
    try {
      const bb = busboy({ headers: req.headers });

      const fields: Record<string, string> = {};
      let fileBuffer: Buffer | null = null;
      let fileInfo: { filename: string; mimetype: string } | null = null;
      let fileCount = 0;
      const chunks: Buffer[] = [];

      let errored = false;

      bb.on("field", (name, val) => {
        fields[name] = val;
      });

      bb.on("file", (_fieldname, file, filename, _encoding, _mimetype) => {
        fileCount++;
        if (fileCount > options.fileLimit) {
          errored = true;
          file.resume(); // drain stream to avoid stuck requests
          return next(
            new CustomError("File limit exceeded", {
              apiMessage: `Only ${options.fileLimit} file(s) allowed`,
              httpCode: httpStatusCodes.EXPECTATION_FAILED,
              responseCode: GeneralApiResponseCode.PROCESSING_FAILED,
              errorName: errorName,
              log: true,
            })
          );
        }

        file.on("data", (chunk) => {
          chunks.push(chunk);
        });

        file.on("end", () => {
          fileInfo = filename;
          fields.file = filename.filename;
          const ext = path.extname(filename.filename).toLowerCase();
          const allowedExtensions = options.allowedExtensions || [];

          if (!allowedExtensions.includes(ext)) {
            errored = true;
            return next(
              new CustomError("Invalid file extension", {
                apiMessage: `Only ${allowedExtensions.join(", ")} files are allowed`,
                httpCode: httpStatusCodes.BAD_REQUEST,
                responseCode: GeneralApiResponseCode.VALIDATION_FAILED,
                errorName: errorName,
                log: true,
              })
            );
          }
          fileBuffer = Buffer.concat(chunks);
        });
      });

      bb.on("finish", () => {
        if (errored) return;

        if (fileCount === 0 || !fileBuffer || !fileInfo) {
          return next(
            new CustomError("No file to process", {
              apiMessage: "No file found to process",
              httpCode: httpStatusCodes.EXPECTATION_FAILED,
              responseCode: GeneralApiResponseCode.PROCESSING_FAILED,
              errorName: errorName,
              log: true,
            })
          );
        }

        // Attach to req
        req.body = fields;
        (req.body as any).fileBuffer = fileBuffer;
        (req.body as any).fileInfo = fileInfo;

        next();
      });

      bb.on("error", (err) => {
        const error = err as any;
        errored = true;
        next(
          new CustomError("Error while converting formdata to body", {
            apiMessage: error?.apiMessage ?? error?.message,
            httpCode: httpStatusCodes.EXPECTATION_FAILED,
            responseCode: GeneralApiResponseCode.PROCESSING_FAILED,
            errorName: errorName,
            log: true,
          })
        );
      });

      req.pipe(bb);
    } catch (error) {
      throw new CustomError("Error while converting formdata to body", {
        apiMessage: error?.apiMessage || error?.message,
        httpCode: httpStatusCodes.EXPECTATION_FAILED,
        responseCode: GeneralApiResponseCode.PROCESSING_FAILED,
        errorName: errorName,
        log: true,
      });
    }
  };
}
