import { NextFunction, Request, Response } from "express";
import httpStatusCodes from "http-status-codes";
import { Roles, ResourceType } from "../constants/enums.constant";
import { verify } from "./verify-token.middleware";
import { USER_HEADERS_KEYS } from "../constants/constants";
import {
  CustomError,
  convertToArray,
  getNestedValue,
} from "../utilities/common.utility";
import ApiResponse, { GeneralApiResponseCode } from "../utilities/api-response";
import Joi from "joi";

type ResourceMap = Partial<Record<ResourceType | string, string>>;

export default function attributeBasedMiddleware(
  allowedRoles: Roles[],
  resources?: ResourceMap
) {
  return async (req: Request, res: Response, next: NextFunction) => {
    let log = false;
    try {
      const headers = req.headers;
      let userId = headers[USER_HEADERS_KEYS.USER_ID];
      let mappingId = headers[USER_HEADERS_KEYS.MAPPING_ID];

      // If headers are missing, fallback to token verification
      if (!userId || !mappingId) {
        if (!(await verify(req))) {
          throw new CustomError("Invalid token");
        }
      }

      log = true;

      userId = req.headers[USER_HEADERS_KEYS.USER_ID];
      mappingId = req.headers[USER_HEADERS_KEYS.MAPPING_ID];
      const roleUserId = Number(req.headers[USER_HEADERS_KEYS.ROLE_USER_ID]);
      const roleId = Number(req.headers[USER_HEADERS_KEYS.ROLE_ID]);

      if (!roleId || !roleUserId) {
        throw new CustomError("Missing role, or role user ID");
      }

      if (!allowedRoles.includes(roleId)) {
        throw new CustomError(
          `Allowed roles: ${allowedRoles.toString()}, Incoming role: ${roleId}`
        );
      }

      const allowed = await validateResources(
        req,
        roleId,
        roleUserId,
        resources
      );
      if (!allowed) {
        throw new CustomError("Access denied: Data does not belong to you!");
      }

      next();
    } catch (error: any) {
      next(
        new CustomError(error.message, {
          responseCode:
            error.responseCode || GeneralApiResponseCode.UNAUTHORIZED,
          httpCode: error.httpCode || httpStatusCodes.FORBIDDEN,
          data: { stack: error.stack, data: error.errorData },
          apiMessage: error.apiMessage || "Access Denied",
          apiData: error.apiData || {},
          errorName: "AttributeMiddlewareError",
          log,
        })
      );
    }
  };
}

async function validateResources(
  req: Request,
  roleId: number,
  roleUserId: number,
  resources: ResourceMap
): Promise<boolean> {
  if (!resources) return true;
  for (const [type, path] of Object.entries(resources)) {
    const typeNum =
      Number(type) ||
      (Number(await getValueFromRequest(req, type)) as ResourceType);
    const ids = convertToArray(
      await getValueFromRequest(req, path),
      false,
      true
    );
    if (ids.length === 0) return false;

    const allMatch = await checkResourceOwnership(typeNum, ids, roleId);
    if (!allMatch) return false;
  }

  return true;
}

async function getValueFromRequest(req: Request, field: string) {
  const fieldFormatted = field.replace(/body.|params.|query./gi, "");
  try {
    ApiResponse.validate(
      req,
      Joi.object({
        [fieldFormatted]: Joi.number().required(),
      })
    );
  } catch (error) {
    throw new CustomError("Field validation failed", {
      apiMessage: error.apiMessage || "Field validation failed",
      apiData: error.apiData || {},
      responseCode: error.responseCode || GeneralApiResponseCode.UNAUTHORIZED,
      httpCode: error.httpCode || httpStatusCodes.EXPECTATION_FAILED,
      log: false,
    });
  }
  const value = getNestedValue(req, field.toString());
  return value;
}

// Stubbed: Replace with actual DB/service calls
async function checkResourceOwnership(
  resourceType: ResourceType,
  resourceIds: number[],
  roleId: number
): Promise<boolean> {
  if (!resourceIds.length) return false;
  resourceIds = convertToArray(resourceIds, true);

  switch (resourceType) {
    case ResourceType.Admin: {
      return roleId == Roles.Admin;
    }
    case ResourceType.Investor:
      break;

    case ResourceType.Ifa:
      break;

    case ResourceType.Rm:
      break;
    default:
      return false;
  }
}
