import { Request, Response, NextFunction } from "express";
import httpStatusCodes from "http-status-codes";
import { TokenInfo, verifyJwtToken } from "../libraries/jwt";
import { USER_HEADERS_KEYS } from "../constants/constants";
import { YESNO, Roles } from "../constants/enums.constant";
import { GeneralApiResponseCode } from "../utilities/api-response";
import {
  CustomError,
  getKeyWithValueFromEnum,
  LogTypes,
} from "../utilities/common.utility";
import { JoinClause } from "../repositories/base.repository";

export async function verify(req: Request): Promise<boolean> {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) throw new CustomError("Token not found");

    const roleId = Number(req.headers[USER_HEADERS_KEYS.ROLE_ID]);
    const roleUserId = Number(req.headers[USER_HEADERS_KEYS.ROLE_USER_ID]);

    if (!roleId || !roleUserId)
      throw new CustomError("Required headers not found");
    if (!getKeyWithValueFromEnum(Roles, roleId))
      throw new CustomError("Invalid Role");

    const decoded: TokenInfo = verifyJwtToken(authHeader);
    const roleData = decoded.mappings[roleId];
    if (!roleData?.roleUserIds.includes(roleUserId)) {
      throw new CustomError("Role user id not found in token mapping");
    }

    const userId = decoded.userId;
    const userTable = "table";
    if (!userTable) throw new CustomError("Role user table not found");

    const joins: JoinClause[] = [
      {
        table: "user",
        alias: "user",
        type: "inner",
        on: [["user.id", "mapping.user_id"]],
      },
    ];

    const where: Record<string, any> = {
      "mapping.user_id": userId,
      "mapping.role_id": roleId,
      "mapping.is_deleted": YESNO.No,
      "user.is_deleted": YESNO.No,
    };

    if (roleId !== Roles.Admin) {
      const alias = "roleUser";
      joins.push({
        table: userTable,
        alias,
        type: "inner",
        on: [
          [`${alias}.user_id`, userId.toString()],
          [`${alias}.id`, roleUserId.toString()],
        ],
      });
      where[`${alias}.is_deleted`] = YESNO.No;
    }

    const result = null;

    if (!result) {
      throw new CustomError("Invalid user");
    }

    req.headers[USER_HEADERS_KEYS.USER_ID] = userId.toString();
    req.headers[USER_HEADERS_KEYS.MAPPING_ID] = result.data[0].id.toString();
    return true;
  } catch (err) {
    throw formatAuthError(err);
  }
}

function formatAuthError(err: any) {
  return new CustomError("Token Verification Failed", {
    apiMessage:
      err.name === "TokenExpiredError"
        ? "Token expired, please login again"
        : "Invalid Token",
    httpCode: httpStatusCodes.UNAUTHORIZED,
    responseCode:
      err.name === "TokenExpiredError"
        ? GeneralApiResponseCode.TOKEN_EXPIRED
        : GeneralApiResponseCode.UNAUTHORIZED,
    errorName: "TokenVerificationFailed",
    logType: LogTypes.ERROR,
    data: { stack: err.stack, data: err },
  });
}

export async function verifyToken(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    await verify(req);
    next();
  } catch (err) {
    next(err);
  }
}
