// middlewares/loggerMiddleware.ts
import { Request, Response, NextFunction } from "express";
import { logger } from "../logger";

// utils/sanitize.ts
const sensitiveKeys = ["password", "token", "authorization", "refreshToken"];

export const sanitizeBody = (obj: Request): any => {
  const data = obj.method === "GET" ? obj.query : obj.body;
  return Object.fromEntries(
    Object.entries(data).map(([key, value]) => {
      if (sensitiveKeys.includes(key.toLowerCase())) {
        return [key, "xxxxxxx"];
      }
      return [key, value];
    })
  );
};

export const requestLogger = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const start = Date.now();
  const sanitizedRequestBody = sanitizeBody(req);
  const chunks: Buffer[] = [];

  // Hook into res.send to capture response body
  const originalSend = res.send.bind(res);
  res.send = function (body) {
    if (body instanceof Buffer) {
      chunks.push(body);
    } else if (typeof body === "string") {
      chunks.push(Buffer.from(body));
    } else {
      chunks.push(Buffer.from(JSON.stringify(body)));
    }
    return originalSend(body);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    const responseBody = Buffer.concat(chunks).toString("utf8");

    logger.info(
      `${req.method} ${req.originalUrl} ${res.statusCode} - ${duration}ms \n` +
        `   Request: ${JSON.stringify(sanitizedRequestBody)}\n` +
        `   Response: ${responseBody.slice(0, 1000)}`
    );
  });

  next();
};
