export const formats = {
  DATE_DISPLAY_FORMAT: "yyyy-MM-dd", // specfic to date-fns
  DATE_TIME_FORMAT: "yyyy-MM-dd HH:mm:ss",
};
