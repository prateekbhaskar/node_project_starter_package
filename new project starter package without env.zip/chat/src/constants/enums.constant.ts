// ─── Environment & Platform ──────────────────────────────
export enum Environment {
  DEVELOPMENT = "development",
  STAGING = "staging",
  PRODUCTION = "production",
}


// ─── Roles & Resource Types ──────────────────────────────
export enum Roles {
  Investor = 1,
  IFA = 2,
  Admin = 3,
  RM = 4,
}

export enum ResourceType {
  Investor = 1,
  Ifa = 2,
  Admin = 3,
  Rm = 4,
  Order = 5,
}
// ─── Auth Config ─────────────────────────────────────────
export const maxLoginAttemtps = 3;
export const maxUploadDocumentAttemtps = 3;
export const otpExpiryMinutes = 10;

export enum YESNO {
  No = 0,
  Yes = 1,
}
