export const VALID_UPLOAD_EXTENSIONS = [
  ".jpg",
  ".jpeg",
  ".png",
  ".pdf",
  ".JPG",
  ".JPEG",
  ".PNG",
];

export const USER_HEADERS_KEYS = {
  USER_ID: "x-user-id",
  MAPPING_ID: "x-mapping-id",
  ROLE_ID: "x-role-id",
  ROLE_USER_ID: "x-role-user-id",
};
