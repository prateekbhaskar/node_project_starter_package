import { createLogger, format, transports } from "winston";
import DailyRotateFile from "winston-daily-rotate-file";
const loggerTransports = [];

loggerTransports.push(
  new DailyRotateFile({
    filename: "logs/app-%DATE%.log",
    datePattern: "YYYY-MM-DD",
    zippedArchive: true,
    maxSize: "10m",
    maxFiles: "1y",
  })
);

export const logger = createLogger({
  level: "info",
  format: format.combine(
    format.timestamp(),
    format.printf(
      ({ timestamp, level, message }) =>
        `[${timestamp}] ${level.toUpperCase()} : ${message}`
    )
  ),
  transports: loggerTransports,
});

export function setDevConsole() {
  const devConsoleFormat = format.combine(
    format.colorize(),
    format.timestamp(),
    format.printf(({ level, message, timestamp, ...meta }) => {
      const metaStr = Object.keys(meta).length
        ? JSON.stringify(meta, null, 2)
        : "";
      return `${timestamp} [${level}]: ${message} ${metaStr}`;
    })
  );
  logger.add(
    new transports.Console({
      format: devConsoleFormat,
    })
  );
}
