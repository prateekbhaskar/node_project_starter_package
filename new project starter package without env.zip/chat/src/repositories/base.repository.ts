import { Knex } from "knex";
import { db } from "../../knex.config";
import {
  CustomError,
  LogTypes,
  safeStringify,
} from "../utilities/common.utility";
import { GeneralApiResponseCode } from "../utilities/api-response";
import httpStatusCode from "http-status-codes";
import BaseModel from "../models/base.model";
import { logger } from "../logger";
import { YESNO } from "../constants/enums.constant";

export interface RepositoryResult<T = any> {
  status: boolean;
  data: T;
}

export type RepositoryUpdateResult = RepositoryResult<number | null>;
export interface RepositoryGetDataResult<T> extends RepositoryResult<T[]> {
  pagination?: {
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
  };
}

export interface IRespository<T = any> {
  insert(payload: Record<string, any>): Promise<RepositoryResult<T>>;
  update(
    payload: Record<string, any>,
    condition: number | Record<string, WhereCondition>
  ): Promise<RepositoryUpdateResult>;
  getData(params: QueryParams): Promise<RepositoryGetDataResult<T>>;
  findById(id: number): Promise<RepositoryGetDataResult<T>>;
}

type WhereCondition =
  | string
  | number
  | boolean
  | null
  | [string, string | number | boolean | null]
  | (string | number | boolean | null)[]; // NEW: to support whereIn arrays

type JoinType = "inner" | "left" | "right" | "full";

export interface JoinClause {
  table: string;
  alias?: string;
  type?: JoinType;
  on: [string, string] | [string, string][];
}

export interface QueryParams {
  select?: string[];
  where?: Record<string, WhereCondition>;
  orWhere?: Record<string, WhereCondition>;
  whereIn?: Record<string, any[]>;
  notIn?: Record<string, any[]>;
  whereNull?: string[];
  whereNotNull?: string[];
  notLike?: Record<string, string>;
  orderBy?: Record<string, "ASC" | "DESC">;
  groupBy?: string[];
  having?: Record<string, WhereCondition>;
  orHaving?: Record<string, WhereCondition>;
  distinct?: boolean;
  raw?: string;
  limit?: number;
  offset?: number;
  page?: number;
  pageSize?: number;
  alias?: string;
  joins?: JoinClause[];
  like?: Record<string, string>;
  aggregations?: {
    [alias: string]: {
      fn: "count" | "sum" | "avg" | "min" | "max";
      column: string;
    };
  };
}

type ExtractModelType<M> = M extends BaseModel<infer T> ? T : never;

export default class BaseRepository<
  M extends new (...args: any) => BaseModel<any>,
> {
  protected readonly table: string;
  private readonly modelClass: M;

  constructor(modelClass: M) {
    this.modelClass = modelClass;
    this.table = (modelClass as any).tableName;
  }

  async insert<R = ExtractModelType<M>>(
    payload: Omit<ExtractModelType<InstanceType<M>>, "id">,
    tx?: Knex.Transaction
  ): Promise<RepositoryResult<R>> {
    const source = tx || db;
    const [insertedId] = await source(this.table).insert(payload);
    if (!insertedId) {
      logger.error(`[${this.table}] Insert failed: no ID returned`);
      return { status: false, data: null };
    }

    //fetch inserted row for audit log
    const inserted = await source(this.table).where({ id: insertedId }).first();

    if (!inserted) {
      logger.error(
        `[${this.table}] Insert failed: record not found after insert`
      );
      return { status: false, data: null };
    }

    return { status: true, data: inserted || null };
  }

  async update(
    payload: Partial<Omit<ExtractModelType<InstanceType<M>>, "id">>,
    condition: number | Record<string, WhereCondition>,
    userId?: number,
    tx?: Knex.Transaction
  ): Promise<RepositoryUpdateResult> {
    let updateRowCount = 0;
    try {
      const source = tx || db;
      const oldDataQuery = this.applyWhereConditions(
        source(this.table),
        condition
      ).select("*");
      const oldData = await oldDataQuery;

      for (const row of oldData) {
        await source(this.table).update(payload).where({ id: row.id });
        updateRowCount++;
      }
    } catch (err) {
      logger.error(`Error creating audit log data ${JSON.stringify(err)}`);
    }

    return { status: updateRowCount > 0, data: updateRowCount };
  }

  async getData<R = ExtractModelType<M>>(
    params: QueryParams,
    tx?: Knex.Transaction
  ): Promise<RepositoryGetDataResult<R>> {
    const source = tx || db;

    const alias = params.alias || this.table;
    const baseTable = params.alias ? `${this.table} as ${alias}` : this.table;

    if (params.joins?.length && !params.alias) {
      throw new CustomError(`Missing alias when using joins on ${this.table}`, {
        apiMessage: "Main Alias required with joins",
        responseCode: GeneralApiResponseCode.PROCESSING_FAILED,
        httpCode: httpStatusCode.BAD_REQUEST,
        errorName: "MissingAliasException",
        logType: LogTypes.WARNING,
      });
    }

    try {
      const query = source(baseTable);
      this.applyJoins(query, params.joins);
      this.applySelect(query, params.select, alias);
      this.applyConditions(query, params, alias, source);

      if (params.page && params.pageSize) {
        const countQuery = source(baseTable);
        this.applyJoins(countQuery, params.joins);
        this.applyConditions(countQuery, { ...params }, alias, source);
        const [{ total }] = await countQuery.count({ total: "*" });
        const totalCount = typeof total === "string" ? parseInt(total) : total;
        const totalPages = Math.ceil(totalCount / params.pageSize);

        query
          .limit(params.pageSize)
          .offset((params.page - 1) * params.pageSize);
        const results = await query;

        return {
          status: results.length > 0,
          data: results,
          pagination: {
            total: totalCount,
            page: params.page,
            pageSize: params.pageSize,
            totalPages,
          },
        };
      }
      const results = await query;
      return {
        status: results.length > 0,
        data: results,
      };
    } catch (error) {
      throw new CustomError(`Error executing getData on table ${this.table}`, {
        apiMessage: "There was some Error",
        responseCode: GeneralApiResponseCode.INTERNAL_SERVER_ERROR,
        httpCode: httpStatusCode.INTERNAL_SERVER_ERROR,
        data: safeStringify(error),
        errorName: "getDataException",
        logType: LogTypes.ERROR,
      });
    }
  }

  async findById<R = ExtractModelType<M>>(
    id: number
  ): Promise<RepositoryResult<R>> {
    return this.findOne<R>({ id: id, is_deleted: YESNO.No });
  }

  // === Private Helpers ===

  private applyWhereConditions(
    query: Knex.QueryBuilder,
    condition: number | Record<string, WhereCondition>
  ) {
    if (typeof condition === "number") {
      return query.where("id", condition);
    }

    for (const [key, value] of Object.entries(condition || {})) {
      if (Array.isArray(value)) {
        if (value.length === 2 && typeof value[0] === "string") {
          // [operator, value]
          query.where(key, value[0], value[1]);
        } else {
          // treat as whereIn
          query.whereIn(key, value);
        }
      } else {
        query.where(key, value);
      }
    }

    return query;
  }

  private applyJoins(query: Knex.QueryBuilder, joins?: JoinClause[]) {
    joins?.forEach(({ table, alias, type = "left", on }) => {
      const joinTable = alias ? `${table} as ${alias}` : table;

      query[`${type}Join`](joinTable, function () {
        for (const [a, b] of on) {
          const isBColumn = typeof b === "string" && b.includes(".");
          if (isBColumn) {
            this.on(a, "=", b); // column = column
          } else {
            this.onVal(a, "=", b); // column = value
          }
        }
      });
    });
  }

  private applySelect(
    query: Knex.QueryBuilder,
    select?: string[],
    alias?: string
  ) {
    if (select?.length) {
      const resolved = select.map((column) => {
        // If column already has a dot, assume it's fully qualified (like "mapping.id")
        if (column.includes(".")) return column;
        // Otherwise wrap with the alias (e.g., "user.id")
        return `${alias}.${column}`;
      });
      query.select(...resolved);
    } else {
      query.select(`${alias}.*`);
    }
  }

  private applyConditions(
    query: Knex.QueryBuilder,
    params: QueryParams,
    alias: string,
    source: Knex | Knex.Transaction
  ) {
    const wrap = (key: string) => (key.includes(".") ? key : `${alias}.${key}`);

    const applyClause = (
      method: "where" | "orWhere" | "having" | "orHaving",
      conditions?: Record<string, WhereCondition>
    ) => {
      if (!conditions) return;
      const entries = Object.entries(conditions || {});
      if (!entries.length) return;

      const isOr = method === "orWhere" || method === "orHaving";

      if (isOr) {
        query[method === "orWhere" ? "where" : "having"](function () {
          for (const [key, value] of entries) {
            const column = wrap(key);
            if (Array.isArray(value)) {
              const [operator, val] = value;
              this[method](column, operator as string, val);
            } else {
              this[method](column, "=", value);
            }
          }
        });
      } else {
        for (const [key, value] of entries) {
          const column = wrap(key);
          if (Array.isArray(value)) {
            const [operator, val] = value;
            query[method](column, operator as string, val);
          } else {
            query[method](column, "=", value);
          }
        }
      }
    };

    applyClause("where", params.where);
    applyClause("orWhere", params.orWhere);
    applyClause("having", params.having);
    applyClause("orHaving", params.orHaving);

    Object.entries(params.whereIn || {}).forEach(([key, values]) =>
      query.whereIn(wrap(key), values)
    );

    Object.entries(params.notIn || {}).forEach(([key, values]) =>
      query.whereNotIn(wrap(key), values)
    );

    Object.entries(params.like || {}).forEach(([key, value]) =>
      query.where(wrap(key), "like", value)
    );

    Object.entries(params.notLike || {}).forEach(([key, value]) =>
      query.whereNot(wrap(key), "like", value)
    );

    (params.whereNull || []).forEach((key) => query.whereNull(wrap(key)));
    (params.whereNotNull || []).forEach((key) => query.whereNotNull(wrap(key)));

    if (params.raw) query.whereRaw(params.raw);

    if (params.aggregations) {
      Object.entries(params.aggregations || {}).forEach(
        ([aliasKey, { fn, column }]) => {
          query.select({ [aliasKey]: source.raw(`${fn}(??)`, [wrap(column)]) });
        }
      );
    }

    if (params.distinct) query.distinct();

    if (params.groupBy?.length) {
      query.groupBy(params.groupBy.map(wrap));
    }

    Object.entries(params.orderBy || {}).forEach(([key, dir]) => {
      query.orderBy(wrap(key), dir);
    });

    if (Number.isInteger(params.limit)) query.limit(params.limit);
    if (Number.isInteger(params.offset)) query.offset(params.offset);
  }

  async findOne<R = ExtractModelType<M>>(
    where: Record<string, WhereCondition>,
    tx?: Knex.Transaction
  ): Promise<RepositoryResult<R>> {
    try {
      const source = tx || db;

      const query = source(this.table).select("*").first();
      this.applyWhereConditions(query, where);

      const result = await query;

      return {
        status: !!result,
        data: result || {},
      };
    } catch (error) {
      throw new CustomError(`Error executing findOne on table ${this.table}`, {
        apiMessage: "Failed to retrieve record",
        responseCode: GeneralApiResponseCode.INTERNAL_SERVER_ERROR,
        httpCode: httpStatusCode.INTERNAL_SERVER_ERROR,
        data: safeStringify(error),
        errorName: "findOneException",
        logType: LogTypes.ERROR,
      });
    }
  }

  async find<R = ExtractModelType<M>>(
    where: Record<string, WhereCondition>,
    tx?: Knex.Transaction
  ): Promise<RepositoryResult<R[]>> {
    try {
      const source = tx || db;
      const query = source(this.table).select("*");
      this.applyWhereConditions(query, where);
      const result = await query;

      return {
        status: !!result,
        data: result || [],
      };
    } catch (error) {
      throw new CustomError(`Error executing findOne on table ${this.table}`, {
        apiMessage: "Failed to retrieve record",
        responseCode: GeneralApiResponseCode.INTERNAL_SERVER_ERROR,
        httpCode: httpStatusCode.INTERNAL_SERVER_ERROR,
        data: safeStringify(error),
        errorName: "findException",
        logType: LogTypes.ERROR,
      });
    }
  }
}
