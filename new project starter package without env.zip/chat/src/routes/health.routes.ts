import apiResponse from "../utilities/api-response";
import httpStatusCodes from "http-status-codes";
import { GeneralApiResponseCode } from "../utilities/api-response";
import { routeFactory } from "..";

export default routeFactory((router) => {
  router.get("/", (req, res) => {
    return apiResponse.result(
      res,
      { status: "healthy" },
      httpStatusCodes.OK,
      GeneralApiResponseCode.SUCCESS
    );
  });
});
