import { Application } from "express";
import healthRoutes from "./health.routes";

export default class Routes {
  constructor(app: Application) {
    app.use("", healthRoutes);
  }
}
