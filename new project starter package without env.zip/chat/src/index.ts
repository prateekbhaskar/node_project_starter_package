import express, { Application, Request, Response, Router } from "express";
import cors, { CorsOptions } from "cors";
import Routes from "./routes";
import { logger } from "./logger";
import apiResponse from "./utilities/api-response";
import httpStatusCodes from "http-status-codes";
import { GeneralApiResponseCode } from "./utilities/api-response";
import { requestLogger } from "./middleware/loggerMiddleware";
import { ErrorHandlerMiddleware } from "./middleware/error-handler";
import {
  CustomError,
  LogTypes,
  stringToArray,
} from "./utilities/common.utility";
import { Environment } from "./constants/enums.constant";
import path from "path";
export default class Server {
  constructor(app: Application) {
    app.use(express.json());
    app.use(requestLogger);
    // Serve frontend static files from a 'public' or 'build' folder
    const frontendPath = path.join(__dirname, "../public"); // adjust as needed
    app.use(express.static(frontendPath));
    this.config(app);
    new Routes(app);

    // For SPA (React/Vue/Angular) - redirect unknown routes to index.html
    app.get("*", (req, res) => {
      res.sendFile(path.join(frontendPath, "index.html"));
    });

    app.use(ErrorHandlerMiddleware);
    app.use((req: Request, res: Response) => {
      apiResponse.result(
        res,
        null,
        httpStatusCodes.NOT_FOUND,
        GeneralApiResponseCode.NOT_FOUND
      );
    });
    logger.info("App load successfully");
  }

  private config(app: Application): void {
    const allowedOrigins = stringToArray(process.env.APP_FRONTEND || "");
    app.use((req, res, next) => {
      (req as any).clientIp =
        typeof req.headers["x-forwarded-for"] === "string"
          ? req.headers["x-forwarded-for"].split(",")[0].trim()
          : req.socket.remoteAddress || "";
      next();
    });

    app.use((req, res, next) => {
      const origin = req.headers.origin;
      const clientIp = (req as any).clientIp || "Unknown IP";

      if (
        process.env.NODE_ENV === Environment.PRODUCTION &&
        (!origin || !allowedOrigins.includes(origin))
      ) {
        logger.error("Request Blocked");
        throw new CustomError(
          `Unauthorised request origin: ${origin || "null"}, IP: ${clientIp}`,
          {
            errorName: "Custom CORS checking",
            apiMessage: "Unauthorised request",
            httpCode: httpStatusCodes.UNAUTHORIZED,
            responseCode: GeneralApiResponseCode.UNAUTHORIZED,
            logType: LogTypes.WARNING,
          }
        );
      }
      next();
    });

    const corsOptions: CorsOptions = {
      origin: true,
      credentials: true,
    };
    app.use(cors(corsOptions));
    app.options("*", cors());
    app.use(express.urlencoded({ extended: true }));
  }
}

export function routeFactory(setup: (router: Router) => void) {
  const router = Router();
  setup(router);
  return router;
}
