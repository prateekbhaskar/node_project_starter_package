import dotenv from "dotenv";
import httpStatusCode from "http-status-codes";
import { differenceInDays, differenceInHours } from "date-fns";
import { logger, setDevConsole } from "../logger";
import { Environment } from "../constants/enums.constant";
import { GeneralApiResponseCode } from "./api-response";
import crypt from "./crypt";

// --------------------- ENVIRONMENT ---------------------
export function loadEnvOnce(): void {
  if (process.env._DOTENV_LOADED === "true") {
    logger.info("env loaded");
    return;
  }

  dotenv.config();
  process.env._DOTENV_LOADED = "true";
  logger.info("env loaded");

  if (process.env.NODE_ENV === Environment.DEVELOPMENT) {
    setDevConsole();
  }
}

// --------------------- DATE UTILS ---------------------
export function differenceInDaysRoundedUp(
  startDate: Date,
  endDate: Date
): number {
  const dayDiff = differenceInDays(startDate, endDate);
  const hourDiff = differenceInHours(startDate, endDate) % 24;
  return hourDiff > 0 ? dayDiff + 1 : dayDiff;
}

export function getEpocSeconds(date: Date): string {
  return Math.floor(date.getTime() / 1000).toString();
}

// --------------------- JSON UTILS ---------------------
export function safeJsonParse(value: unknown): any | null {
  try {
    if (!value) return null;
    if (typeof value === "string") return JSON.parse(value);
    if (typeof value === "object") return value;
    return null;
  } catch (err) {
    logger.error(err);
    return null;
  }
}

export const isValidJSON = (str: string): boolean => {
  try {
    JSON.parse(str);
    return true;
  } catch (e) {
    logger.error(e);
    return false;
  }
};

export function safeStringify(obj: any): string {
  try {
    // For any kind of error, gather all own properties
    if (obj instanceof Error) {
      const plainObject: Record<string, any> = {};

      // Get all own property names (including non-enumerable)
      for (const key of Object.getOwnPropertyNames(obj)) {
        plainObject[key] = (obj as any)[key];
      }

      return JSON.stringify(plainObject, getCircularReplacer(), 2);
    }

    return JSON.stringify(obj, getCircularReplacer(), 2);
  } catch {
    return String(obj);
  }
}

function getCircularReplacer() {
  const seen = new WeakSet();
  return (_key: string, value: any) => {
    if (typeof value === "object" && value !== null) {
      if (seen.has(value)) return "[Circular]";
      seen.add(value);
    }
    return value;
  };
}

// --------------------- ENUM ---------------------
export function getKeyWithValueFromEnum(
  enumObject: object,
  value: number | string
): string | undefined {
  return Object.keys(enumObject).find(
    (key) => enumObject[key as keyof typeof enumObject] === value
  );
}

// --------------------- STRING / ARRAY UTILS ---------------------
export const stringToArray = (input: string, separator = ","): string[] =>
  input.split(separator).map((item) => item.trim());

export function convertToArray(
  data: string | number | any[] = null,
  numberArray = false,
  csv = false
): any[] {
  let responseArray: any[] = [];

  if (typeof data === "number") {
    responseArray = [data];
  } else if (typeof data === "string") {
    responseArray = csv ? stringToArray(data) : [data];
  } else if (Array.isArray(data)) {
    responseArray = [...data];
  }

  if (numberArray) {
    responseArray = responseArray.map(Number).filter((num) => !isNaN(num));
  }

  return [...new Set(responseArray)];
}

export function getNestedValue(obj: object, path: string): any {
  return path.split(".").reduce((acc, key) => acc?.[key], obj);
}

export function buildFullAddress(addr?: any): string {
  if (!addr) return "";
  return [
    addr.address_line_1,
    addr.address_line_2,
    addr.city,
    addr.state,
    addr.pin_code,
  ]
    .filter(Boolean)
    .join(" ");
}

// --------------------- NUMBER / FORMAT ---------------------
export function toFixedTrunc(num: number, fixed: number): string {
  const re = new RegExp(`^-?\\d+(?:\\.\\d{0,${fixed}})?`);
  const match = num.toString().match(re);
  return match ? match[0] : "0";
}

export function getNumberFormat(
  number: number,
  minFraction: number,
  maxFraction: number
): string {
  return new Intl.NumberFormat("en-IN", {
    minimumFractionDigits: minFraction,
    maximumFractionDigits: maxFraction,
  }).format(number);
}

export function decimalApproximation(
  num: number,
  {
    precision = 2,
    roundUpIfNextDigitGreaterThan = 4,
    base = 10,
  }: {
    precision?: number;
    roundUpIfNextDigitGreaterThan?: number;
    base?: number;
  } = {}
): number | null {
  if (!Number.isFinite(num)) return null;
  if (
    !Number.isInteger(precision) ||
    precision < 0 ||
    !Number.isInteger(roundUpIfNextDigitGreaterThan) ||
    roundUpIfNextDigitGreaterThan < 0 ||
    roundUpIfNextDigitGreaterThan >= base
  ) {
    throw new CustomError("Invalid input for decimal approximation", {
      httpCode: httpStatusCode.UNPROCESSABLE_ENTITY,
      responseCode: GeneralApiResponseCode.PROCESSING_FAILED,
    });
  }

  const factor = base ** precision;
  const scaled = Math.abs(num) * factor;
  const nextDigit = Math.trunc(scaled * base) % base;
  const adjusted =
    (Math.trunc(scaled) + (nextDigit > roundUpIfNextDigitGreaterThan ? 1 : 0)) /
    factor;
  return Math.sign(num) * adjusted;
}

// --------------------- DB HELPERS ---------------------
export function removeNonRequiredDbData(
  input: Record<string, any> | Record<string, any>[]
): Record<string, any> | Record<string, any>[] {
  const sensitiveFields: string[] = ["ifsc_code", "account_number"];
  const process = (element: Record<string, any>) => {
    const {
      created_at: _created_at,
      created_by: _created_by,
      updated_at: _updated_at,
      updated_by: _updated_by,
      is_deleted: _is_deleted,
      deleted_at: _deleted_at,
      meta_data: _meta_data,
      password: _password,
      pan,
      aadhaar_number,
      ...rest
    } = element;

    if (pan) {
      rest.pan = crypt.decrypt(pan.toString());
    }

    // Decrypt + mask Aadhaar if exists
    if (aadhaar_number) {
      rest.aadhaar_number = maskString(
        crypt.decrypt(aadhaar_number.toString())
      );
    }

    for (const field of sensitiveFields) {
      if (rest[field]) rest[field] = crypt.decrypt(rest[field].toString());
    }

    return rest;
  };

  return Array.isArray(input) ? input.map(process) : process(input);
}

// --------------------- ERROR ---------------------
export enum LogTypes {
  ERROR = 0,
  WARNING = 1,
  INFO = 2,
}

export class CustomError extends Error {
  httpCode: number;
  responseCode: number | string;
  errorData: any;
  apiData?: any;
  apiMessage?: string;
  log: boolean = true;
  logType: LogTypes = LogTypes.INFO;

  constructor(
    message: string,
    {
      httpCode,
      responseCode,
      data,
      apiData,
      apiMessage,
      errorName = "CustomError",
      log = true,
      logType = LogTypes.INFO,
    }: {
      httpCode?: number;
      responseCode?: number | string;
      data?: any;
      apiData?: any;
      apiMessage?: string;
      errorName?: string;
      log?: boolean;
      logType?: LogTypes;
    } = {}
  ) {
    super(message);
    Object.setPrototypeOf(this, new.target.prototype);
    if (Error.captureStackTrace)
      Error.captureStackTrace(this, this.constructor);

    this.name = errorName;
    this.httpCode = httpCode;
    this.responseCode = responseCode;
    this.errorData = data;
    this.apiData = apiData;
    this.apiMessage = apiMessage;
    this.log = log;
    this.logType = logType;

    if (this.log) {
      const logData = JSON.stringify({
        name: this.name,
        message: this.message,
        httpCode: this.httpCode,
        responseCode: this.responseCode,
        errorData: this.errorData,
        apiMessage: this.apiMessage,
        apiData: this.apiData,
      });
      switch (this.logType) {
        case LogTypes.ERROR:
          logger.error(logData);
          break;
        case LogTypes.WARNING:
          logger.warn(logData);
          break;
        default:
          logger.info(logData);
          break;
      }
    }
  }
}

export function maskString(str: string, unMaskedChars: number = 4): string {
  if (!str) return null;
  if (str.length <= unMaskedChars) return str;
  return "*".repeat(str.length - unMaskedChars) + str.slice(-unMaskedChars);
}
