import { Request, Response } from "express";
import httpStatusCodes from "http-status-codes";
import Joi from "joi";
import { ServiceResponse } from "./response";
import { CustomError } from "./common.utility";

export const GeneralApiResponseCode = {
  SUCCESS: "success",
  UNAUTHORIZED: "unauthorized",
  API_FAILED: "api_failed",
  VALIDATION_FAILED: "validation_failed",
  PROCESSING_FAILED: "processing_failed",
  NOT_FOUND: "not_found",
  INTERNAL_SERVER_ERROR: "internal_server_error",
  TOKEN_EXPIRED: "token_expired",
  OTP_REQUIRED: "otp_required",
};

export enum ResponseType {
  Json = 1,
  PlainText = 2,
  CSV = 3,
}

export default class ApiResponse {
  static result = (
    res: Response,
    data: object | any,
    status: number,
    code: string,
    type: ResponseType = ResponseType.Json,
    outputFileName: string = "output"
  ) => {
    let isSuccess = false;
    if (status >= 200 && status < 300) {
      isSuccess = true;
    }
    res.status(status);
    if (type == ResponseType.CSV) {
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename=${outputFileName}.csv`
      );
      // Stream CSV as Binary Data
      res.send(Buffer.from(data, "utf-8"));
    } else {
      if (isSuccess) {
        res.json({
          data,
          success: true,
          code: code,
        });
      } else {
        res.json({
          error: data,
          success: false,
          code: code,
        });
      }
    }
  };

  static validate = (
    req: Request,
    schema: Joi.ObjectSchema | Joi.ArraySchema,
    validationOptions: Joi.ValidationOptions = { convert: true }
  ): boolean => {
    const validationResult = schema.validate(
      { ...req.body, ...req.params, ...req.query },
      {
        abortEarly: false,
        allowUnknown: true,
        ...validationOptions,
      }
    );
    if (validationResult.error) {
      const errors: { label: string; message: string }[] = [];
      for (const error of validationResult.error.details) {
        errors.push({
          label: error.context.label,
          message: error.message,
        });
      }
      throw new CustomError("Validation failed", {
        apiData: errors,
        responseCode: GeneralApiResponseCode.VALIDATION_FAILED,
        httpCode: httpStatusCodes.BAD_REQUEST,
        apiMessage: "Field Validation failed",
        errorName: "ApiFieldValidationError",
        log: false,
      });
    }
    return true;
  };

  static controllerResponse(res: Response, serviceResponse: ServiceResponse) {
    return this.result(
      res,
      serviceResponse.success
        ? serviceResponse.data
        : { message: serviceResponse.message, error: serviceResponse.error },
      serviceResponse.httpCode,
      serviceResponse.errorType
    );
  }
}
