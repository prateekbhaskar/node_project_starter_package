import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  createHmac,
} from "crypto";
import md5 from "md5";
import { logger } from "../logger";

class Crypt {
  algorithm = "aes-256-cbc";
  key = null;
  private getKey() {
    if (!this.key) {
      this.key = Buffer.from(
        process.env.APP_KEY.replace("base64:", ""),
        "base64"
      );
    }
    return this.key;
  }
  // Function to encrypt text
  encrypt(text: string): string {
    const iv = randomBytes(16); // Generate a new IV for each encryption
    const cipher = createCipheriv(this.algorithm, this.getKey(), iv);
    let encrypted = cipher.update(text, "utf8", "base64");
    encrypted += cipher.final("base64");

    // Generate a MAC (Message Authentication Code) for integrity check
    const ivBase64 = iv.toString("base64");
    const hmac = createHmac("sha256", this.getKey());
    hmac.update(ivBase64 + encrypted);
    const mac = hmac.digest("base64");
    // Create a JSON object with IV, encrypted data, and MAC
    const data = {
      iv: ivBase64,
      value: encrypted,
      mac: mac,
    };
    return Buffer.from(JSON.stringify(data)).toString("base64");
  }

  // Function to decrypt text
  decrypt(encryptedText: string): string {
    try {
      // Decode and parse the JSON object
      const data = JSON.parse(
        Buffer.from(encryptedText, "base64").toString("utf8")
      );

      // Extract IV, encrypted value, and MAC
      const iv = Buffer.from(data.iv, "base64");
      const encrypted = data.value;
      const mac = data.mac;

      // Recompute the MAC to verify data integrity
      const hmac = createHmac("sha256", this.getKey());
      hmac.update(iv.toString("base64") + encrypted);
      const computedMac = hmac.digest("base64");

      if (computedMac !== mac) {
        throw new Error("MAC verification failed");
      }

      // Decrypt the data
      const decipher = createDecipheriv(this.algorithm, this.getKey(), iv);
      let decrypted = decipher.update(encrypted, "base64", "utf8");
      decrypted += decipher.final("utf8");
      return decrypted;
    } catch (error) {
      logger.warn(
        `Failed to decrypt- ${JSON.stringify(encryptedText)}, error: ${JSON.stringify(error)}`
      );
      return null;
    }
  }
  createHmac(algorithm: string, secret: string, text: string) {
    return createHmac(algorithm, secret).update(text).digest("hex");
  }

  match(raw: string, encrypted: string) {
    if (raw === this.decrypt(encrypted)) {
      return true;
    }
    return false;
  }
  async stringUpperAndEncryptAndHash(string: string | null): Promise<{
    upper: string | null;
    hash: string | null;
    encrypt: string | null;
  }> {
    let string_upper: string = null,
      stringMd5: string = null,
      stringEncrypt: string = null;
    if (string) {
      string_upper = string.toUpperCase();
      stringMd5 = md5(string_upper);
      stringEncrypt = this.encrypt(string_upper);
    }
    return {
      upper: string_upper,
      hash: stringMd5,
      encrypt: stringEncrypt,
    };
  }
}
export default new Crypt();
