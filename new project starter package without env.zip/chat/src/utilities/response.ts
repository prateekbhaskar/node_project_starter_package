import { GeneralApiResponseCode } from "./api-response";
import httpStatusCodes from "http-status-codes";

export interface ServiceResponse<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
  error?: any;
  errorType: string;
  httpCode: number;
}

export const createSuccessResponse = <T>(
  data: T,
  message = "Success",
  errorType = GeneralApiResponseCode.SUCCESS
): ServiceResponse<T> => ({
  success: true,
  message,
  data,
  errorType,
  httpCode: httpStatusCodes.OK,
});

export const createFailureResponse = (
  message: string,
  error?: any,
  errorType = GeneralApiResponseCode.PROCESSING_FAILED,
  httpCode = httpStatusCodes.BAD_REQUEST
): ServiceResponse => ({
  success: false,
  message,
  error,
  errorType,
  httpCode,
});
