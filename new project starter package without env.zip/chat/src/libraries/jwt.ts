import jwt from "jsonwebtoken";

const config = {
  JWT_SECRET_KEY: process.env.JWT_SECRET_KEY,
  JWT_EXPIRY: process.env.JWT_TOKEN_TIMEOUT ?? "30m",
  JWT_REFRESH_EXPIRY: process.env.JWT_REFRESH_TOKEN_TIMEOUT ?? "1h",
};

export const generateToken = (
  payload,
  options: { appendKey?: string; refreshToken?: boolean } = {
    refreshToken: false,
  }
) => {
  const secret = options.appendKey
    ? config.JWT_SECRET_KEY + options.appendKey
    : config.JWT_SECRET_KEY;
  const expiry = options.refreshToken
    ? config.JWT_REFRESH_EXPIRY
    : config.JWT_EXPIRY;
  const token = jwt.sign(payload, secret, { expiresIn: expiry });
  return token;
};

export interface RefreshTokenInfo {
  userId: number;
  timeStamp: Date;
}
export interface TokenInfo {
  userId: number;
  mappings?: any;
  iat?: number;
  exp?: number;
}

export const verifyJwtToken = (
  token: string,
  options: { appendKey?: string } = {}
): TokenInfo | RefreshTokenInfo => {
  const secret = options.appendKey
    ? config.JWT_SECRET_KEY + options.appendKey
    : config.JWT_SECRET_KEY;
  const decoded = jwt.verify(cleanToken(token), secret, {
    ignoreExpiration: false,
  });
  return decoded;
};

export const decodeRawToken = (token: string): TokenInfo => {
  return jwt.decode(cleanToken(token));
};

function cleanToken(token: string): string {
  return token.replace("Bearer ", "");
}
