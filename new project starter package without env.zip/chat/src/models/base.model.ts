export default abstract class BaseModel<T> {
  static tableName: string;
  static schema: any;
  declare __modelShape: T;
}
