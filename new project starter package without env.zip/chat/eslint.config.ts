import js from "@eslint/js";
import tseslint from "typescript-eslint";
import globals from "globals";
import prettier from "eslint-config-prettier";

export default tseslint.config(
  {
    ignores: [
      ".node_modules/*",
      ".git/",
      "dist/*",
      "build/*",
      "coverage/*",
      "*/**/*.d.ts",
    ],
  },
  js.configs.recommended,
  tseslint.configs.recommended,
  prettier,
  {
    files: ["**/*.ts", "**/*.tsx"],
    rules: {
      "no-undef": "error",
      "no-console": "error",
      "prefer-const": "error",
      semi: "off",
      quotes: ["error", "double"],
      "no-unexpected-any": "off",
      "@typescript-eslint/no-explicit-any": "off",
      "max-len": ["error", { code: 120 }],
      "no-explicit-any": "off",
      // Allow unused args if they start with "_"
      "@typescript-eslint/no-unused-vars": [
        "error",
        {
          argsIgnorePattern: "^_",
          varsIgnorePattern: "^_",
        },
      ],
    },
    languageOptions: {
      ecmaVersion: 2020,
      sourceType: "module",
      globals: {
        ...globals.node,
        ...globals.browser,
        ...globals.commonjs,
        ...globals.es2015,
        ...globals.es2017,
        ...globals.es2020,
        ...globals.jest,
      },
      parserOptions: {},
    },
    linterOptions: {
      noInlineConfig: false,
      reportUnusedDisableDirectives: true,
    },
  }
);
