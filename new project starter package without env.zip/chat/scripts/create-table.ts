import { loadEnvOnce } from "../src/utilities/common.utility";
import fs from "fs-extra";
import glob from "fast-glob";
import { logger } from "../src/logger";

// --- Bootstrap ---
loadEnvOnce();

const inputTableName = process.argv[2];
if (!inputTableName) {
  logger.error(
    "Missing table name. Usage: npx ts-node generate-entity.ts <table-name>"
  );
  process.exit(1);
}

// --- Helper Functions ---
const normalize = (str: string) => str.replace(/[_-]+/g, "-");
const pascalCase = (str: string) =>
  str.replace(/(^\w|[_-]\w)/g, (s) => s.replace(/[_-]/, "").toUpperCase());
const timestamp = () =>
  new Date()
    .toISOString()
    .replace(/[-:.TZ]/g, "")
    .slice(0, 14);

// --- Derived Names ---
const tableName = inputTableName;
const normalizedName = normalize(tableName);
const pascalName = pascalCase(normalizedName);
const time = timestamp();

// --- File Paths ---
const paths = {
  migration: {
    glob: `migrations/*_create_${normalizedName}_table.ts`,
    file: `migrations/${time}_create_${normalizedName}_table.ts`,
  },
  model: `src/models/${normalizedName}.model.ts`,
  repository: `src/repositories/${normalizedName}.repository.ts`,
};

const modelTemplate = `import BaseModel from "./base.model";
import { IsDeleted } from "../constants/enums.constant";

export interface ${pascalName} {
  id?: number;
  // Add other fields here

  created_by?: number;
  updated_by?: number;
  created_at?: Date;
  updated_at?: Date;
  is_deleted?: IsDeleted;
}

export class ${pascalName}Model extends BaseModel<${pascalName}> {
  static override tableName = "${tableName}";
}
`;

// --- Templates ---
const migrationTemplate = `import { Knex } from "knex";
import { IsDeleted } from "../src/constants/enums.constant";
import { ${pascalName}Model } from "../src/models/${normalizedName}.model";

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable(${pascalName}Model.tableName, (table) => {
    table.increments("id").unsigned().primary();
    // Add other columns here

    table.integer("created_by").unsigned().nullable();
    table.integer("updated_by").unsigned().nullable();
    table.timestamp("created_at").defaultTo(knex.fn.now()).notNullable();
    table.timestamp("updated_at").notNullable()
      .defaultTo(knex.raw("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"));
    table.tinyint("is_deleted").unsigned().defaultTo(IsDeleted.No)
      .comment(Object.values(IsDeleted).toString())
      .notNullable()
      .checkIn((Object.values(IsDeleted).filter(v => typeof v === "number") as number[]).map(String));
  });
}

export async function down(): Promise<void> {
  // rollback logic here
}
`;

const repoTemplate = `import BaseRepository from "./base.repository";
import { ${pascalName}Model } from "../models/${normalizedName}.model";

export default new class ${pascalName}Repository extends BaseRepository<typeof ${pascalName}Model> {
  constructor() {
    super(${pascalName}Model);
  }
}
`;

// --- File Writer Utility ---
async function writeFileIfNotExists(
  path: string,
  content: string,
  label: string
) {
  const exists = await fs.pathExists(path);
  if (exists) {
    logger.warn(`${label} already exists: ${path}`);
  } else {
    await fs.outputFile(path, content.trim() + "\n");
    logger.info(`Created ${label}: ${path}`);
  }
}

// --- Main ---
async function generateEntity() {
  try {
    const existingMigrations = await glob(paths.migration.glob);
    if (existingMigrations.length > 0) {
      logger.warn(`Migration already exists: ${existingMigrations[0]}`);
    } else {
      await writeFileIfNotExists(
        paths.migration.file,
        migrationTemplate,
        "migration"
      );
    }

    await writeFileIfNotExists(paths.model, modelTemplate, "model");
    await writeFileIfNotExists(paths.repository, repoTemplate, "repository");
  } catch (err) {
    logger.error("Error generating entity files", err);
    process.exit(1);
  }
}

generateEntity();
