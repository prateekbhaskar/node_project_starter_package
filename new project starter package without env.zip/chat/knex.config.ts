import { loadEnvOnce } from "./src/utilities/common.utility";
loadEnvOnce();
import { knex, type Knex } from "knex";
import chalk from "chalk";

let db: Knex;
let dbTracing: boolean = false;

function getConfiguration(): Knex.Config {
  const prefix = "MYSQL_";
  const env = process.env;

  if (!env) {
    throw new Error("Environment variables not loaded. Check loadEnvOnce.");
  }

  const configuration: Knex.Config = {
    client: "mysql2",
    connection: {
      host: env[`${prefix}HOST`] || "",
      user: env[`${prefix}USER`] || "",
      password: env[`${prefix}PASSWORD`] || "",
      database: env[`${prefix}DATABASE`] || "",
      port: Number(env[`${prefix}PORT`] || 3306),
      timezone: "Z",
    },
    pool: {
      min: 2,
      max: 500,
      acquireTimeoutMillis: 10000,
    },
    compileSqlOnError: false,
    debug: dbTracing,
    migrations: {
      directory: "migrations",
      tableName: "knex_migrations",
      disableMigrationsListValidation: true,
    },
  };
  return configuration;
}

function setChalking(connection: Knex): void {
  connection.on("query", (qd) => {
    /* eslint-disable no-console */
    console.log(
      chalk.bgGreen(
        "\n\n====================================== START ======================================\n"
      )
    );
    console.log(chalk.cyan.underline.bold("Query:"));
    console.log(chalk.cyan(qd.sql), "\n");
    console.log(chalk.yellow.underline.bold("Query Bindings:"));
    console.log(chalk.yellow(qd.bindings));
    console.log(
      chalk.bgGreen(
        "\n====================================== END ========================================\n\n"
      )
    );
    /* eslint-enable no-console */
  });
}

(async () => {
  dbTracing = process.env.DB_TRACE === "true";
  db = knex(getConfiguration());
  if (dbTracing) {
    setChalking(db);
  }
})();

export default (async () => {
  if (
    process.argv.some((arg) => arg.includes("migrate") || arg.includes("seed"))
  ) {
    const config = getConfiguration();
    db = knex(config);
    return config;
  }
  return undefined;
})();

export { db };
