import express from "express";
import killPort from "kill-port";
import { logger } from "./src/logger"; // your logger
import Server from "./src/index"; // your server setup
import { loadEnvOnce } from "./src/utilities/common.utility";

(async () => {
  try {
    loadEnvOnce();

    const PORT = Number(process.env.PORT) || 8080;

    try {
      await killPort(PORT);
      logger.info(`✅ Killed any process on port ${PORT}`);
    } catch (err) {
      logger.info(
        `ℹ️ No process was running on port ${PORT} or failed to kill: ${err}`
      );
    }

    const app = express();
    new Server(app);

    app
      .listen(PORT, () => {
        logger.info(`🚀 Server is running on http://localhost:${PORT}`);
      })
      .on("error", (err) => {
        logger.error("❌ Failed to start server", { err });
        process.exit(1);
      });
  } catch (err) {
    logger.error("❌ Failed to initialize application", err);
    process.exit(1);
  }
})();
